public enum StateEnum {
  Up,Down,Left,Right
}
